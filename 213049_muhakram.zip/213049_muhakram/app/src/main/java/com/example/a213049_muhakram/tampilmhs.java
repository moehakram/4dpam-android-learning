package com.example.a213049_muhakram;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class tampilmhs extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tampilmhs);
    }
}