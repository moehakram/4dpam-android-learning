package com.example.a213049_muhakram;

public class konfigurasi {
    public static final String URL_TAMBAH = "http://192.168.1.102/dashboard/mobilexakram/tambahmhs.php";
    public static final String URL_ALLTAMPILMHS = "http://192.168.1.102/dashboard/mobilexakram/alltampilmhs.php";
    public static final String URL_TAMPILMHS = "http://192.168.1.102/dashboard/213049_mobile/tampilmhs.php";
    public static final String URL_UBAHMHS = "http://192.168.1.102/dashboard/213049_mobile/updatemhs.php";
    public static final String URL_HAPUSMHS = "http://192.168.1.102/dashboard/213049_mobile/hapusmhs.php";

    public static final String KEY_MHS_NIM = "nim";
    public static final String KEY_MHS_NAMA = "nama";
    public static final String KEY_MHS_JURUSAN = "jurusan";

    public static final String TAG_JSON_ARRAY = "result";
    public static final String TAG_NIM = "nim";
    public static final String TAG_NAMA = "nama";
    public static final String TAG_JURUSAN = "jurusan";

    public static final String MHS_NIM = "mhs_nim";
}