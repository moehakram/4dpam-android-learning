package com.example.a213049_muhakram;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class layout2 extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout2);


    }
}